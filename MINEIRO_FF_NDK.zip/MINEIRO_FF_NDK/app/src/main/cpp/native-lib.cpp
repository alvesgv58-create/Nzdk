#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_mineiroff_panel_MainActivity_nativeStatus(JNIEnv* env, jobject /* thiz */) {
    const std::string status = "MINEIRO FF • NDK nativo carregado";
    return env->NewStringUTF(status.c_str());
}
