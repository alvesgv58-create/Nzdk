MINEIRO FF — AndroidIDE + NDK
================================

O que inclui:
- Interface HTML em assets/index.html (copie o arquivo MINEIRO_FF_V2/index.html para cá).
- Activity Android com WebView.
- Integração JNI/C++ via NDK + CMake.
- Exemplo nativo apenas para exibir status de carregamento.

Não inclui injeção de código, leitura/escrita da memória de Free Fire, aimbot funcional ou bypass de anti-cheat. A biblioteca nativa é apenas um exemplo de integração JNI.

COMPILAÇÃO NO ANDROIDIDE
1. Extraia o ZIP.
2. Copie o seu MINEIRO_FF_V2/index.html para:
   app/src/main/assets/index.html
   (crie a pasta assets se necessário).
3. Abra a pasta do projeto no AndroidIDE.
4. Instale/configure JDK 17, Android SDK Platform 35, NDK e CMake 3.22.1.
5. Execute Gradle: :app:assembleDebug
6. APK: app/build/outputs/apk/debug/app-debug.apk

NDK:
- CMake: 3.22.1
- ABI: arm64-v8a e armeabi-v7a
- C++17

Se o AndroidIDE não tiver o NDK/CMake compatível, a sincronização pode falhar até os componentes corretos serem instalados.
